import {useEffect, useState} from 'react'
import Students from './componentss/Students';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  // stateful value-functoin pair of student variable
  const[students, setStudents] = useState([])
  //fetch student
  const fetchStudents = async () =>{
    const source = await fetch('https://api.hatchways.io/assessment/students')
    var initJson = await source.json()
    // converting JSON object to Array to be able to use map and filter object
    const data = Array.from(initJson.students)
    // console.log(data)
    return data
  }
  //employing useEffect hook for seemless experience
  useEffect(() => {
    const getStudents = async () => {
      const studentsFromApi = await fetchStudents()
      setStudents(studentsFromApi)
    }
    getStudents()
  }, [])

  // stateful value-functoin pair of search-bar variable
  const [searchQueryString, setSearchQueryString] = useState("")

  return (
    <div className="App container">
      <header>
      </header>
      <div className="parent-container">
        <div className='container student-card-container'>
          <div className="name-search-bar w-100">
            <input type="text" placeholder="Search first or last name ..." onChange={
                (query) => {
                    setSearchQueryString(query.target.value)
                }
            }/>
          </div>
        <Students students={students.filter((value) => {
          if(searchQueryString===""){
            return value
          } else if(value.firstName.toLowerCase().includes(searchQueryString.toLowerCase()) || value.lastName.toLowerCase().includes(searchQueryString.toLowerCase())){
            return value
          } else if(value.firstName.toLowerCase()===searchQueryString.toLocaleLowerCase().substr(0,searchQueryString.indexOf(' ')) && value.lastName.toLowerCase()===searchQueryString.toLocaleLowerCase().substr(searchQueryString.indexOf(' ')+1)){
            return value
          } else if(value.firstName.toLowerCase()===searchQueryString.toLocaleLowerCase().substr(0,searchQueryString.indexOf(' ')) && value.lastName.toLowerCase().includes(searchQueryString.toLocaleLowerCase().substr(searchQueryString.indexOf(' ')+1))){
            return value
          }
        })} className="container"/>
        </div>
      </div>
    </div>
  );
}

export default App;
