import Tag from "./Tag";

const Tags = ({tags, onDelete}) => {
    console.log("inside Tags: "+ tags.then())
    return(
        <div className="tags-container">
            {tags.map((tag, index) =>{
                <Tag tag={tag} key={index} onDelete={onDelete}/>
            })}
        </div>
    )
}
export default Tags