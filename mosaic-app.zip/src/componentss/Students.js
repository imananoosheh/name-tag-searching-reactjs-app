import Student from "./Student";

const Students = ({students}) => {
    // console.log('students typeof' + typeof students)
    return(
        <>
            {students.map((student, index) => (
                <Student key={index} student={student}/>
            ))}
        </>
    )
}

export default Students