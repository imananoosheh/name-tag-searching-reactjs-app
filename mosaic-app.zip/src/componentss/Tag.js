const Tag = ({tag, studentId, onDelete}) => {
    return(
        <button type="button" className="btn btn-primary">
            {tag}
            <span className="badge badge-light" onClick={() => onDelete(tag, studentId)}> X </span>
        </button>
    )
}
export default Tag