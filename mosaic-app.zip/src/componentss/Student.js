import ExpandableButton from "./ExpandableButton"
import AddTag from "./AddTag"
import Tags from "./Tags"
import { useState, useEffect } from "react"



const Student = ({student}) => {
    const [showGrades, setShowGrades] = useState(false)
    // const [tags, setTags] = useState([])

    // useEffect(() => {
    //     const getTags = async () => {
    //       const tagsFromDb = await fetchTags()
    //       setTags(tagsFromDb)
    //     }
    
    //     getTags()
    //   }, [])
    
    //   // Fetch Tags
    //   const fetchTags = async () => {
    //     const res = await fetch('http://localhost:5000/studentTags')
    //     const data = await res.json()
    //     return data
    //   }
    
    //   // Fetch Tag
    //   const fetchTag = async (id) => {
    //     const res = await fetch(`http://localhost:5000/studentTags/${id}`)
    //     const data = await res.json()
    //     return data
    //   }
    
    //   // Add Tag
    //   const addTag = async (tag) => {
    //     const res = await fetch('http://localhost:5000/tasks', {
    //       method: 'POST',
    //       headers: {
    //         'Content-type': 'application/json',
    //       },
    //       body: JSON.stringify(tag),
    //     })
    
    //     const data = await res.json()
    
    //     setTags([...tags, data])
    
    //   }
    
    //   // Delete Tag
    //   const deleteTag = async (id) => {
    //     const res = await fetch(`http://localhost:5000/studentTags/${id}`, {
    //       method: 'DELETE',
    //     })
    //     //cheking the status to make sure it was successful
    //     res.status === 200
    //       ? setTags(tags.filter((tag) => tag.id !== id))
    //       : alert('Error Deleting This Task')
    //   }

    
    var averageGrade = () => {
        var sum=0
        for(var i=0; i<student.grades.length; i++){
            sum += parseFloat(student.grades[i])
        }
        return sum/student.grades.length
    }
    return(
        <div className='student-card row'>
            <div className="student-pic col-3">
                <img src={student.pic} alt={"Profile picture of "+student.firstName+" "+student.lastName}></img>
            </div>
            <div className='student-info col-7'>
                <h2>{student.firstName}{' '}{student.lastName}</h2>
                <p>{"Email: "}
                    <a href={"mailto:"+student.email}>{student.email}</a>
                </p>
                <p>{"Company: "+ student.company}</p>
                <p>{"Skill: "+student.skill}</p>
                <p>{"Average: "+averageGrade()+'%'}</p>
                {showGrades && <div className="grades">
                    {student.grades.map((val, key) => {
                        return(<p>{"Test "+(key+1)+":    "+val+"%"}</p>)
                    })}
                </div>}
                {/* <AddTag onAdd={addTag}/>
                <Tags tags={tags} onDelete={deleteTag}/> */}
            </div>
            <div className="col-2">
                <ExpandableButton onDisplay={() => setShowGrades(!showGrades)} showGrades={showGrades}/>
            </div>
        </div>
    )
}
export default Student

